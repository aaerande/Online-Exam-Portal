package exam.action;

import exam.dao.RegisterDao;

public class RegisterAction {
	
	private String emailid,username,password,confirm_password;
	
	
	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConfirm_password() {
		return confirm_password;
	}


	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}


	public String execute()
	{
		int res;
		res=RegisterDao.save(this);
		if(res>0)
		{
		return "success";
		}
		else
		{
			return "error";
		}
		
	}

}
