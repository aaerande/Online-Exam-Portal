package exam.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import exam.dao.RegisterDao;

public class LoginAction implements SessionAware {

	String username,password;
	Map m;
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String execute()
	{
		m.put("username", username);
		m.put("password", password);
		int res=RegisterDao.check(this);
		if(res>0)
		{
			return "success";
		}
		else
		{
			return "error";
		}
	}

	@Override
	public void setSession(Map m) {
		// TODO Auto-generated method stub
		System.out.println("set session called automatically");
		this.m=m;
		
	}
}
