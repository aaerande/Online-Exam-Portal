package exam.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import exam.action.LoginAction;
import exam.action.RegisterAction;

public class RegisterDao {
	
	public static int save(RegisterAction r)
	{
		int status=0;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
			
			PreparedStatement pstmt=conn.prepareStatement("insert into register_user values(?,?,?)");
			pstmt.setString(1, r.getEmailid());
			pstmt.setString(2, r.getUsername());
			pstmt.setString(3, r.getPassword());
			
			status=pstmt.executeUpdate();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
	}
	public static int check(LoginAction r)
	{
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
			
			PreparedStatement pstmt=conn.prepareStatement("select * from register_user where username=? and password=?");
			pstmt.setString(1, r.getUsername());
			pstmt.setString(2, r.getPassword());
			
			ResultSet res=pstmt.executeQuery();
			while(res.next())
			{
				return 1;
			}
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
	}

}
