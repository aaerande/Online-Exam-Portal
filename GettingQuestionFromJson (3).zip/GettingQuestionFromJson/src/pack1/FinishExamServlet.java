package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import javafx.animation.Interpolator;

/**
 * Servlet implementation class FinishExamServlet
 */
public class FinishExamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinishExamServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int noofque=5;
		int i=0;
		System.out.println("server of finishexam called");
		String []corectresult={"option1","option2","option2","option2","option1"};
		String[]actualresult=new String[10];
		
		//System.out.println(request.getParameter("res"));
		System.out.println("-------------------------------------------------------------------");
		String result=request.getParameter("res");
		try {
			org.json.JSONObject object=new org.json.JSONObject(result);
			for(i=0;i<corectresult.length;i++)
			{
				actualresult[i]=(String) object.get(new Integer(i+1).toString());
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		Map<String, String[]>map=request.getParameterMap();
		Iterator<Entry<String, String[]>>ent= map.entrySet().iterator();
		int size=map.size();
		System.out.println("map size="+size);
		while(ent.hasNext())
		{
			Entry<String, String[]> entry=ent.next();
			System.out.println(entry.getKey());
			String []arr=entry.getValue();
			System.out.println(arr[0].toString());
			actualresult[i]=arr[0].toString();
			i++;
		}
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		System.out.println("-----------------------------------------------------------------");*/
		
		int correctnumber=0;
		for(i=0;i<corectresult.length;i++)
		{
			if(corectresult[i].equals(actualresult[i]))
			{
				correctnumber++;
			}
		}
		PrintWriter out=response.getWriter();
		
		/*JSONObject obj=new JSONObject();
		obj.put("number", 5);
		obj.put("correct", correctnumber);
		obj.put("incorrect", (5-correctnumber));
		obj.put("per",correctnumber*20);
		out.print(obj);		*/
		
		out.println("Number of questions="+5+"<br>");
		out.print("Number of correct Questions="+correctnumber+"<br>");
		out.println("Number of incorrect question="+""+(5-correctnumber)+"<br>");
		out.println("Percentage="+correctnumber*20+"<br>");
		
		
		
		
		//System.out.println(map);
		//JSONParser parser=new Json
		/*String []arr=result.split("_");
		for(int i=0;i<noofque;i++)
		{
			String []optres=arr[i].split(",");
			System.out.println(optres[1]);
			actualresult[i]=optres[1];
		}
		int correct=0;
		for(int j=0;j<actualresult.length;j++)
		{
			if(corectresult[j].equals(actualresult[j]))
			{
				correct++;
				System.out.println(correct);
			}
		}*/
		/*PrintWriter out=response.getWriter();
		JSONObject obj=new JSONObject();
		obj.put("number", 5);
		obj.put("correct", correct);
		obj.put("incorrect", (5-correct));
		obj.put("per",correct*20);
//		out.println("Number of questions="+5+"<br>");
//		out.print("Number of correct Questions="+correct+"<br>");
//		out.println("Number of incorrect question="+""+(5-correct)+"<br>");
//		out.println("Percentage="+correct*20+"<br>");
		out.print(obj);
		*/

		
		
		
		
	}

}
