package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import javafx.animation.Interpolator;

/**
 * Servlet implementation class FinishExamServlet
 */
public class FinishExamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinishExamServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int noofque=5;
		System.out.println("server of finishexam called");
		String []corectresult={"option1","option2","option2","option2","option1"};
		String[]actualresult=new String[5];
		
		//System.out.println(request.getParameter("res"));
		String result=request.getParameter("res");
		Map<String, String[]>map=request.getParameterMap();
		Iterator<Entry<String, String[]>>ent= map.entrySet().iterator();
		while(ent.hasNext())
		{
			Entry<String, String[]> entry=ent.next();
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		
		System.out.println(map);
		//JSONParser parser=new Json
		/*String []arr=result.split("_");
		for(int i=0;i<noofque;i++)
		{
			String []optres=arr[i].split(",");
			System.out.println(optres[1]);
			actualresult[i]=optres[1];
		}
		int correct=0;
		for(int j=0;j<actualresult.length;j++)
		{
			if(corectresult[j].equals(actualresult[j]))
			{
				correct++;
				System.out.println(correct);
			}
		}*/
		/*PrintWriter out=response.getWriter();
		JSONObject obj=new JSONObject();
		obj.put("number", 5);
		obj.put("correct", correct);
		obj.put("incorrect", (5-correct));
		obj.put("per",correct*20);
//		out.println("Number of questions="+5+"<br>");
//		out.print("Number of correct Questions="+correct+"<br>");
//		out.println("Number of incorrect question="+""+(5-correct)+"<br>");
//		out.println("Percentage="+correct*20+"<br>");
		out.print(obj);
		*/
	}

}
