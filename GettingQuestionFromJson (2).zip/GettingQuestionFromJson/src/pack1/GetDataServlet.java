package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class GetDataServlet
 */
public class GetDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetDataServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("do get method called");
		PrintWriter out=response.getWriter();
//		out.write("What is java?,programming language platform framework none");
		JSONArray array=new JSONArray();
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
			System.out.println("coming inside the try block");
			Statement stmt=conn.createStatement();
			String data=request.getParameter("getd");
			ResultSet res=stmt.executeQuery("select * from question_list");
			while(res.next())
			{
				JSONObject obj=new JSONObject();
				obj.put("question", res.getString(1));
				obj.put("option1", res.getString(2));
				obj.put("option2", res.getString(3));
				obj.put("option3", res.getString(4));
				obj.put("option4", res.getString(5));
				obj.put("questionno",res.getInt(6));
				array.add(obj);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject fin=new JSONObject();
		fin.put("que", array);
		out.print(fin);
		
		
	}

	

}
